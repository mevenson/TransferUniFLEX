﻿namespace CenteredMessageboxDemo
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnRegularMessageBox = new System.Windows.Forms.Button();
			this.btnShowCenteredMessageBox = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// btnRegularMessageBox
			// 
			this.btnRegularMessageBox.Location = new System.Drawing.Point(47, 34);
			this.btnRegularMessageBox.Name = "btnRegularMessageBox";
			this.btnRegularMessageBox.Size = new System.Drawing.Size(199, 23);
			this.btnRegularMessageBox.TabIndex = 0;
			this.btnRegularMessageBox.Text = "Show Regular MessageBox";
			this.btnRegularMessageBox.UseVisualStyleBackColor = true;
			this.btnRegularMessageBox.Click += new System.EventHandler(this.btnRegularMessageBox_Click);
			// 
			// btnShowCenteredMessageBox
			// 
			this.btnShowCenteredMessageBox.Location = new System.Drawing.Point(47, 76);
			this.btnShowCenteredMessageBox.Name = "btnShowCenteredMessageBox";
			this.btnShowCenteredMessageBox.Size = new System.Drawing.Size(199, 23);
			this.btnShowCenteredMessageBox.TabIndex = 1;
			this.btnShowCenteredMessageBox.Text = "Show Centered MessageBox";
			this.btnShowCenteredMessageBox.UseVisualStyleBackColor = true;
			this.btnShowCenteredMessageBox.Click += new System.EventHandler(this.btnShowCenteredMessageBox_Click);
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(292, 133);
			this.Controls.Add(this.btnShowCenteredMessageBox);
			this.Controls.Add(this.btnRegularMessageBox);
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "Form1";
			this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
			this.Text = "CenteredMessageboxDemo";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Button btnRegularMessageBox;
		private System.Windows.Forms.Button btnShowCenteredMessageBox;
	}
}

