﻿using System;
using System.Windows.Forms;

namespace CenteredMessageboxDemo
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		private void Form1_Load(object sender, EventArgs e)
		{

		}

		private void btnRegularMessageBox_Click(object sender, EventArgs e)
		{
			MessageBox.Show("Regular MessageBox.\nThis should be centered on the screen.", "CenteredMessageboxDemo", MessageBoxButtons.OK, MessageBoxIcon.Information);
		}

		private void btnShowCenteredMessageBox_Click(object sender, EventArgs e)
		{
			MsgBox.Show("Centered MessageBox.\nThis should be centered on it's parent form.", "CenteredMessageboxDemo", MessageBoxButtons.OK, MessageBoxIcon.Information);
		}
	}
}
